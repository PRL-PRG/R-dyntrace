.onUnload <- function(libpath)
    library.dynam.unload("survival", libpath)

