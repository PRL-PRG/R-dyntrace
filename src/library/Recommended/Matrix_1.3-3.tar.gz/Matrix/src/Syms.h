SEXP
    Matrix_betaSym,
    Matrix_DimNamesSym,
    Matrix_DimSym,
    Matrix_diagSym,
    Matrix_factorSym,
    Matrix_iSym,
    Matrix_jSym,
    Matrix_lengthSym,
    Matrix_LSym, Matrix_RSym, Matrix_USym,
    Matrix_pSym,
    Matrix_permSym,
    Matrix_uploSym,
    Matrix_VSym,
    Matrix_xSym,

    Matrix_NS;/* the Matrix Namespace ('environment') */



