# $Id: cluster.S 11166 2008-11-24 22:10:34Z therneau $
cluster <- function(x) x
